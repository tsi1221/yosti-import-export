export const ACCESS_TOKEN = 'access_token';
export const ACCESS_CURRENT_USER = 'current_user';