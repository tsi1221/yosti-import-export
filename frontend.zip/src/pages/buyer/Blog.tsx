
// src/pages/buyer/Blog.tsx
import React from "react";
export default function Blog() {
  return <div className="p-6"><h1>Blog & News</h1></div>;
}

