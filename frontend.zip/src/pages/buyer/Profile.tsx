// src/pages/buyer/Profile.tsx
import React from "react";
export default function BuyerProfile() {
  return <div className="p-6"><h1>Profile</h1></div>;
}
