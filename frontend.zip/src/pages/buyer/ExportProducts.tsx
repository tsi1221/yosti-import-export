// src/pages/buyer/ExportProducts.tsx
import React from "react";
export default function ExportProducts() {
  return <div className="p-6"><h1>Export Products</h1></div>;
}