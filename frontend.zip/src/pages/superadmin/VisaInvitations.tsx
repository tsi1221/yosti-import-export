
// src/pages/superAdmin/VisaInvitations.tsx
import React from "react";
export default function AllVisaInvitations() {
  return <div className="p-6"><h1>Visa Invitations</h1></div>;
}
