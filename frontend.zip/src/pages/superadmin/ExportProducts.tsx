// src/pages/superAdmin/ExportProducts.tsx
import React from "react";
export default function AllExportProducts() {
  return <div className="p-6"><h1>Export Products all (Add/Edit)</h1></div>;
}