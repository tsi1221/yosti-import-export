// src/pages/superAdmin/Payments.tsx
import React from "react";
export default function AllPayments() {
  return <div className="p-6"><h1>Payments</h1></div>;
}