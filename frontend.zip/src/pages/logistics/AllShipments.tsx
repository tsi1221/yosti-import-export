
// src/pages/logistics/AllShipments.tsx
import React from "react";
export default function AllShipments() {
  return <div className="p-6"><h1>All Shipments</h1></div>;
}










