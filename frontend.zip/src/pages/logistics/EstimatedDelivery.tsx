// src/pages/logistics/EstimatedDelivery.tsx
import React from "react";
export default function EstimatedDelivery() {
  return <div className="p-6"><h1>Estimated Delivery</h1></div>;
}