// src/pages/logistics/UploadDocs.tsx
import React from "react";
export default function UploadDocs() {
  return <div className="p-6"><h1>Upload Shipment Docs</h1></div>;
}
