
// src/pages/logistics/Logout.tsx
import React from "react";
export default function Logout() {
  return <div className="p-6"><h1>Logout</h1></div>;
}