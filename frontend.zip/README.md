  { email: "buyer@example.com", password: "password123", role: "buyer" },








  
  { email: "supplier@example.com", password: "password123", role: "supplier" },







  
  { email: "admin@example.com", password: "password123", role: "admin" },







  
  { email: "superadmin@example.com", password: "password123", role: "super-admin" },





  
  { email: "logistics@example.com", password: "password123", role: "logistics" },
